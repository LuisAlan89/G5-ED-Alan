﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Numeros
    {
        public double num;
        public double Num { set; get; }
        public double Num2 { set; get; }
        public string Opera { set; get; }
        public Numeros()
        {
            Num = 0;
            Num2 = 0;
        }

        public double Resultado()
        {
            
            if (Opera == "+")
            {
                 num = Num + Num2;
            }
            if (Opera == "-") 
            {
                if (Num2 != 0)
                {
                    num = Num - Num2;
                }
                else
                {
                    num = Num;
                }                
            }
            if (Opera == "*")
            {
                num = Num * Num2;
            }
            if (Opera == "/")
            {
                if (Num2 != 0)
                {
                    num = Num / Num2;
                }
                else
                {
                    num = Num;
                }                
            }  
            if(Opera == "X^")
            {
                num = Math.Pow((Num), Num2);
            }
            if(Opera == "√")
            {
                num = Math.Sqrt(Num);
            }
            return num;
        }
    }
}
