﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        Numeros nus = new Numeros();
        bool igual = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "2";            
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += "0";
        }

        private void btnPunto_Click(object sender, EventArgs e)
        {
            txtOperacion.Text += ".";
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            txtOperacion.Text = string.Empty;
            txtPreview.Text = string.Empty;
            nus.num = 0;
            nus.Num = 0;
            nus.Num2 = 0;
        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
            {
                nus.Num = Convert.ToDouble(txtOperacion.Text);
                nus.Opera = "+";
                txtPreview.Text += txtOperacion.Text;
                txtPreview.Text += nus.Opera;
                txtOperacion.Text = "";
            }
                 
        }

        private void btnResta_Click(object sender, EventArgs e)
        {
            if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
            {
                nus.Num = Convert.ToDouble(txtOperacion.Text);
                nus.Opera = "-";
                txtPreview.Text += txtOperacion.Text;
                txtPreview.Text += nus.Opera;
                txtOperacion.Text = "";
            }
        }

        private void btnMultiplica_Click(object sender, EventArgs e)
        {
            if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
            {
                nus.Num = Convert.ToDouble(txtOperacion.Text);
                nus.Opera = "*";
                txtPreview.Text += txtOperacion.Text;
                txtPreview.Text += nus.Opera;
                txtOperacion.Text = "";
            }
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
            {
                nus.Num = Convert.ToDouble(txtOperacion.Text);
                nus.Opera = "/";
                txtPreview.Text += txtOperacion.Text;
                txtPreview.Text += nus.Opera;
                txtOperacion.Text = "";
            }
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
            {
                if (igual != false)
                {
                    txtPreview.Text += nus.Opera;
                    txtPreview.Text += nus.Num2;
                    txtOperacion.Text = nus.Resultado().ToString();
                }
                else
                {
                    nus.Num2 = Convert.ToDouble(txtOperacion.Text);
                    txtPreview.Text += txtOperacion.Text;
                    txtOperacion.Text = nus.Resultado().ToString();
                    igual = false;
                }
                
            }
        }

        private void bntBorrar_Click(object sender, EventArgs e)
        {
            if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
            {
                txtOperacion.Text = txtOperacion.Text.Substring(0, txtOperacion.Text.Length - 1);
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExponente_Click(object sender, EventArgs e)
        {
            if(txtOperacion.Text != string.Empty || txtOperacion.Text != "")
            {
                nus.Num = Convert.ToDouble(txtOperacion.Text);
                nus.Opera = "X^";
                txtPreview.Text += txtOperacion.Text;
                txtPreview.Text += nus.Opera;
                txtOperacion.Text = "";
            }
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
            {
                nus.Num = Convert.ToDouble(txtOperacion.Text);
                nus.Opera = "√";
                txtPreview.Text += txtOperacion.Text;

                txtOperacion.Text = nus.Resultado().ToString();
                igual = false;
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            txtOperacion.Focus();
            switch (e.KeyCode)
            {
                case Keys.NumPad0:
                    txtOperacion.Text += "0";
                    break;
                case Keys.NumPad1:
                    txtOperacion.Text += "1";
                    break;
                case Keys.NumPad2:
                    txtOperacion.Text += "2";
                    break;
                case Keys.NumPad3:
                    txtOperacion.Text += "3";
                    break;
                case Keys.NumPad4:
                    txtOperacion.Text += "4";
                    break;
                case Keys.NumPad5:
                    txtOperacion.Text += "5";
                    break;
                case Keys.NumPad6:
                    txtOperacion.Text += "6";
                    break;
                case Keys.NumPad7:
                    txtOperacion.Text += "7";
                    break;
                case Keys.NumPad8:
                    txtOperacion.Text += "8";
                    break;
                case Keys.NumPad9:
                    txtOperacion.Text += "9";
                    break;
                case Keys.Enter:
                    if(txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        if(igual != false)
                        {
                            txtPreview.Text = nus.Opera;
                            txtPreview.Text += nus.Num2;
                            txtOperacion.Text = nus.Resultado().ToString();

                        }
                        else
                        {
                            nus.Num2 = Convert.ToDouble(txtOperacion.Text);
                            txtPreview.Text += txtOperacion.Text;
                            txtOperacion.Text = nus.Resultado().ToString();
                            igual = false;
                        }
                    }
                    break;

                case Keys.Delete:
                    if(txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {

                        txtOperacion.Text = string.Empty;
                        txtPreview.Text = string.Empty;
                        nus.num = 0;
                        nus.Num = 0;
                        nus.Num2 = 0;


                    }
                    break;

                case Keys.Back:
                    if(txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        txtOperacion.Text = txtOperacion.Text.Substring(0, txtOperacion.Text.Length - 1);
                    }
                    break;

                case Keys.Add:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "+";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }

                    break;

                case Keys.Subtract:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "-";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }
                    break;

                case Keys.Multiply:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "*";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }
                    break;

                case Keys.Divide:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "/";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }
                    break;
            }
        }

        private void txtOperacion_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtOperacion_KeyDown(object sender, KeyEventArgs e)
        {
            txtOperacion.Focus();
            switch (e.KeyCode)
            {
                case Keys.NumPad0:
                    txtOperacion.Text += "0";
                    break;
                case Keys.NumPad1:
                    txtOperacion.Text += "1";
                    break;
                case Keys.NumPad2:
                    txtOperacion.Text += "2";
                    break;
                case Keys.NumPad3:
                    txtOperacion.Text += "3";
                    break;
                case Keys.NumPad4:
                    txtOperacion.Text += "4";
                    break;
                case Keys.NumPad5:
                    txtOperacion.Text += "5";
                    break;
                case Keys.NumPad6:
                    txtOperacion.Text += "6";
                    break;
                case Keys.NumPad7:
                    txtOperacion.Text += "7";
                    break;
                case Keys.NumPad8:
                    txtOperacion.Text += "8";
                    break;
                case Keys.NumPad9:
                    txtOperacion.Text += "9";
                    break;
                
                case Keys.Enter:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        if (igual != false)
                        {
                            txtPreview.Text = nus.Opera;
                            txtPreview.Text += nus.Num2;
                            txtOperacion.Text = nus.Resultado().ToString();

                        }
                        else
                        {
                            nus.Num2 = Convert.ToDouble(txtOperacion.Text);
                            txtPreview.Text += txtOperacion.Text;
                            txtOperacion.Text = nus.Resultado().ToString();
                            igual = false;
                        }
                    }
                    break;

                case Keys.Delete:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {

                        txtOperacion.Text = string.Empty;
                        txtPreview.Text = string.Empty;
                        nus.num = 0;
                        nus.Num = 0;
                        nus.Num2 = 0;


                    }
                    break;

                case Keys.Back:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        txtOperacion.Text = txtOperacion.Text.Substring(0, txtOperacion.Text.Length - 1);
                    }
                    break;

                case Keys.Add:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "+";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }

                    break;

                case Keys.Subtract:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "-";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }
                    break;

                case Keys.Multiply:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "*";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }
                    break;

                case Keys.Divide:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "/";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }
                    break;
                case Keys.F:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "√";
                        txtPreview.Text += txtOperacion.Text;

                        txtOperacion.Text = nus.Resultado().ToString();
                        igual = false;
                    }
                    break;
                case Keys.G:
                    if (txtOperacion.Text != string.Empty || txtOperacion.Text != "")
                    {
                        nus.Num = Convert.ToDouble(txtOperacion.Text);
                        nus.Opera = "X^";
                        txtPreview.Text += txtOperacion.Text;
                        txtPreview.Text += nus.Opera;
                        txtOperacion.Text = "";
                    }
                    break;
                    
            }
        }
    }
}

